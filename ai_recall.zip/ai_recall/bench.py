"""Local embedding benchmark: hash vs ONNX-CPU vs ONNX-NPU (the last only on a Snapdragon device).

  python bench.py --n 300
Writes data/bench.csv so you can paste NPU vs CPU latency into the hackathon slides.
"""
import argparse
import csv
import time

from airecall.embedder import HashEmbedder, get_embedder

TEXTS = ["link down on interface eth0", "voltage spike detected on supply rail, exceeds configured limit",
         "over temperature shutdown triggered, node entering safe mode", "sensor read timeout on channel 3",
         "firmware update started version=<*>", "network latency high to gateway latency_ms=<*>"]

ap = argparse.ArgumentParser()
ap.add_argument("--n", type=int, default=300)
a = ap.parse_args()
texts = (TEXTS * (a.n // len(TEXTS) + 1))[:a.n]

backends = [("hash", HashEmbedder())]
for prov in ("cpu", "qnn"):
    try:
        backends.append((f"onnx-{prov}", get_embedder("onnx", prov)))
    except Exception as e:
        print(f"skip onnx-{prov}: {e}")

rows = []
for name, emb in backends:
    emb.encode(texts[:8])  # warm-up
    t0 = time.perf_counter()
    emb.encode(texts)
    dt = time.perf_counter() - t0
    rows.append([name, emb.device, a.n, round(dt * 1000 / a.n, 3), round(a.n / dt, 1)])
    print(f"{name:<10} device={emb.device:<4} {dt * 1000 / a.n:8.3f} ms/text  {a.n / dt:9.1f} texts/s")

with open("data/bench.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["backend", "device", "n", "ms_per_text", "texts_per_s"])
    w.writerows(rows)
print("saved data/bench.csv")
