"""AI Recall: offline, natural-language recall over edge logs."""
