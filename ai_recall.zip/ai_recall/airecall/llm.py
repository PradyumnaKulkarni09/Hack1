"""Optional local SLM helpers (query planner + answer phrasing) over an OpenAI-compatible endpoint.

Point RECALL_LLM_URL at a server on THIS machine (llama.cpp server, Ollama, a Genie/QNN wrapper...):
    RECALL_LLM_URL=http://127.0.0.1:11434/v1/chat/completions
    RECALL_LLM_MODEL=llama3.2:3b
Remote hosts are refused unless RECALL_ALLOW_REMOTE=1, to keep the 'nothing leaves the device' promise.
If anything fails the caller falls back to the rule-based planner, so the demo never breaks.
"""
from __future__ import annotations

import json
import os
import re
import urllib.parse
import urllib.request
from datetime import timedelta

from .nlq import FMT, Plan

SYSTEM = """You convert questions about device logs into a JSON query. Reply with JSON only, keys:
intent: one of last|first|count|max|min|avg|list
field: a numeric field from FIELDS, or null
op: ">" or "<" or null; value: number or null
node: one of NODES or null; level: ERROR|WARN|CRIT|INFO or null
last_hours: number or null (only if the question limits the time window)
text: key words describing the event type for text search, or "" if the question is about a numeric field."""


def available() -> bool:
    return bool(os.getenv("RECALL_LLM_URL"))


def ssl_context(url):
    """TLS settings for the endpoint.
    RECALL_CA_BUNDLE=<path to .pem/.crt>  trust your company's / the server's certificate (preferred).
    RECALL_INSECURE_TLS=1                 skip certificate checks, ONLY allowed for private/loopback IPs."""
    import ipaddress
    import ssl
    ca = os.getenv("RECALL_CA_BUNDLE")
    if ca:
        return ssl.create_default_context(cafile=ca)
    if os.getenv("RECALL_INSECURE_TLS") == "1":
        host = urllib.parse.urlparse(url).hostname or ""
        try:
            private = ipaddress.ip_address(host).is_private
        except ValueError:
            private = False
        if not private:
            raise RuntimeError("RECALL_INSECURE_TLS is only allowed for private IP addresses")
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    return None


def _chat(messages, max_tokens=300, timeout=60):
    url = os.environ["RECALL_LLM_URL"]
    host = urllib.parse.urlparse(url).hostname
    if host not in ("127.0.0.1", "localhost", "::1") and os.getenv("RECALL_ALLOW_REMOTE") != "1":
        raise RuntimeError(f"refusing non-local LLM endpoint {host}")
    body = json.dumps({"model": os.getenv("RECALL_LLM_MODEL", "llama3.2:3b"), "messages": messages,
                       "temperature": 0, "max_tokens": max_tokens}).encode()
    headers = {"Content-Type": "application/json"}
    key = os.getenv("RECALL_LLM_API_KEY")
    if key:  # Authorization: Bearer <key> by default; Azure-style gateways use RECALL_LLM_AUTH_HEADER=api-key
        name = os.getenv("RECALL_LLM_AUTH_HEADER", "Authorization")
        headers[name] = f"Bearer {key}" if name.lower() == "authorization" else key
    req = urllib.request.Request(url, body, headers)
    with urllib.request.urlopen(req, timeout=timeout, context=ssl_context(url)) as r:
        return json.load(r)["choices"][0]["message"]["content"]


def plan_with_llm(question, nodes, fields, now):
    try:
        out = _chat([{"role": "system", "content": SYSTEM + f"\nFIELDS={fields}\nNODES={nodes}"},
                     {"role": "user", "content": question}])
        d = json.loads(re.search(r"\{.*\}", out, re.S).group(0))
        p = Plan()
        p.intent = d.get("intent") if d.get("intent") in ("last", "first", "count", "max", "min", "avg", "list") else "list"
        p.field = d.get("field") if d.get("field") in fields else None
        p.op = d.get("op") if d.get("op") in (">", "<") else None
        p.value = float(d["value"]) if d.get("value") is not None else None
        p.node = d.get("node") if d.get("node") in nodes else None
        p.level = d.get("level") if d.get("level") in ("ERROR", "WARN", "CRIT", "INFO") else None
        if d.get("last_hours"):
            p.t_from = (now - timedelta(hours=float(d["last_hours"]))).strftime(FMT)
        p.text = (d.get("text") or "").strip()
        if p.field and not p.text:
            p.mode = "metric"
            p.direction = "down" if p.op == "<" else "up"
        p.note = "planned by local LLM"
        return p
    except Exception:
        return None


def phrase_answer(question, answer, evidence_lines):
    try:
        ev = "\n".join(evidence_lines[:8])
        return _chat([{"role": "system", "content": "Answer the question in 1-2 sentences using ONLY the facts given. "
                       "Quote timestamps exactly. Do not invent anything."},
                      {"role": "user", "content": f"Question: {question}\nFacts: {answer}\nLog lines:\n{ev}"}],
                     max_tokens=120).strip()
    except Exception:
        return None
