"""Natural-language question -> structured query Plan.

Rule-based, so it runs offline with no model. llm.py can optionally replace it with a local SLM planner
and falls back to this. Numeric questions ("voltage above 250") become SQL over the metrics table;
everything else becomes semantic search over log templates.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timedelta

FMT = "%Y-%m-%dT%H:%M:%S"
UP = r"(?:above|over|exceed(?:s|ed|ing)?|greater than|more than|higher than|larger than|beyond|>=?)"
DOWN = r"(?:below|under|less than|lower than|smaller than|<=?)"
NUM = r"(-?\d+(?:\.\d+)?)"
SPIKE_WORDS = r"\b(?:spik\w*|surg\w*|peak\w*|exceed\w*|threshold|overvolt\w*|abnormal\w*|anomal\w*|too high)\b"
DIP_WORDS = r"\b(?:sag\w*|dip\w*|drop\w*|brownout|undervolt\w*|too low)\b"
SYN = {"voltage": ["volt", "volts", "voltages"], "temp": ["temperature", "temperatures", "temps"],
       "current": ["amp", "amps", "ampere", "amperes"]}
GENERIC = set("""show me list all give find what were was is are the a an in on at of to for from by with any that
this there when did does do last first latest most recent time times how many much count number again since past
ago today yesterday please tell about than and or then log logs entry entries event events happened happen occur
occurred occurrences reading readings value values hour hours minute minutes day days week weeks my our which
who had has have been be it its as go went gone""".split())
LEVEL_WORDS = {"error": "ERROR", "errors": "ERROR", "warning": "WARN", "warnings": "WARN", "warn": "WARN",
               "critical": "CRIT", "crit": "CRIT", "info": "INFO"}


@dataclass
class Plan:
    intent: str = "list"          # last | first | count | max | min | avg | list
    mode: str = "semantic"        # metric | semantic
    field: str | None = None
    op: str | None = None
    value: float | None = None
    direction: str | None = None  # up | down: used to auto-pick a threshold when none is given
    node: str | None = None
    level: str | None = None
    t_from: str | None = None
    t_to: str | None = None
    text: str = ""
    note: str = ""


def _fmt(d):
    return d.strftime(FMT)


def _find_node(ql, nodes):
    for n in nodes:
        if n.lower() in ql:
            return n, n.lower()
    m = re.search(r"\b(?:edge|node|device)[-_ ]?0*(\d+)\b", ql)
    if m:
        for n in nodes:
            tail = re.search(r"(\d+)$", n)
            if tail and int(tail.group(1)) == int(m.group(1)):
                return n, m.group(0)
    return None, None


def _find_time(ql, now):
    """Return (t_from, t_to, matched_text). 'now' is the newest log time, so old datasets still work."""
    m = re.search(r"\b(?:last|past|previous)\s+(\d+)\s*(minute|min|hour|hr|day|week)s?\b", ql)
    if m:
        n, u = int(m.group(1)), m.group(2)
    else:
        m = re.search(r"\b(?:last|past)\s+(minute|hour|day|week)\b", ql)
        n, u = (1, m.group(1)) if m else (None, None)
    if m:
        unit = {"minute": "minutes", "min": "minutes", "hour": "hours", "hr": "hours", "day": "days", "week": "weeks"}[u]
        return _fmt(now - timedelta(**{unit: n})), None, m.group(0)
    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
    if "yesterday" in ql:
        return _fmt(midnight - timedelta(days=1)), _fmt(midnight), "yesterday"
    if "today" in ql:
        return _fmt(midnight), None, "today"
    m = re.search(r"\b(since|after|before|on)\s+(\d{4}-\d\d-\d\d)\b", ql)
    if m:
        d = datetime.strptime(m.group(2), "%Y-%m-%d")
        if m.group(1) in ("since", "after"):
            return _fmt(d), None, m.group(0)
        if m.group(1) == "before":
            return None, _fmt(d), m.group(0)
        return _fmt(d), _fmt(d + timedelta(days=1)), m.group(0)
    return None, None, ""


def _find_field(ql, fields):
    best = None
    for f in fields:
        aliases = {f, f.split("_")[0]} | set(SYN.get(f, []))
        for a in aliases:
            m = re.search(rf"\b{re.escape(a)}s?\b", ql)
            if m and (best is None or m.start() < best[0]):
                best = (m.start(), f)
    return best[1] if best else None


def parse(question: str, nodes, fields, now: datetime) -> Plan:
    q = question.strip()
    ql = q.lower()
    p = Plan()
    rest = ql

    p.node, span = _find_node(ql, nodes)
    if span:
        rest = rest.replace(span, " ")
    p.t_from, p.t_to, span = _find_time(ql, now)
    if span:
        rest = rest.replace(span, " ")
    p.field = _find_field(ql, fields)

    # threshold ("above 250", "< 30")
    m = re.search(rf"({UP}|{DOWN})\s*{NUM}", ql)
    if m:
        is_down = re.fullmatch(DOWN, m.group(1)) is not None
        p.value = float(m.group(2))
        p.op = "<" if is_down else ">"
        if ">=" in m.group(1) or "<=" in m.group(1):
            p.op += "="
        p.direction = "down" if is_down else "up"
        rest = rest.replace(m.group(0), " ")
    if re.search(SPIKE_WORDS, ql) and not p.direction:
        p.direction = "up"
    if re.search(DIP_WORDS, ql):
        p.direction = "down"
    if not p.direction and re.search(r"\b(?:above|exceed\w*|beyond|greater|higher)\b", ql):
        p.direction = "up"

    # intent
    if re.search(r"\bhow (?:many|often)\b|\bcount\b|\bnumber of\b|\btotal\b", ql):
        p.intent = "count"
    elif re.search(r"\b(?:average|mean|avg)\b", ql):
        p.intent = "avg"
    elif re.search(r"\b(?:max|maximum|highest|largest|biggest)\b", ql):
        p.intent = "max"
    elif re.search(r"\b(?:min|minimum|lowest|smallest)\b", ql):
        p.intent = "min"
    elif re.search(r"\b(?:first|earliest|oldest)\b", ql):
        p.intent = "first"
    elif re.search(r"\blast\b(?!\s+(?:\d+|hours?|days?|weeks?|minutes?|mins?)\b)|\bmost recent\b|\blatest\b|"
                   r"\bwhen (?:was|did|is|were)\b|\brecent(?:ly)?\b", ql):
        p.intent = "last"

    # level
    for w in re.findall(r"[a-z]+", ql):
        if w in LEVEL_WORDS:
            p.level = LEVEL_WORDS[w]
            rest = re.sub(rf"\b{w}\b", " ", rest)

    # numeric or text?
    if p.field and (p.value is not None or p.intent in ("avg", "max", "min", "count") or p.direction):
        p.mode = "metric"
        if p.level:
            p.level = None
    words = [w for w in re.findall(r"[a-z0-9]+", rest) if w not in GENERIC]
    p.text = " ".join(words)
    return p
