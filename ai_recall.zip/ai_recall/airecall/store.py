"""Local memory: SQLite (structured fields) + numpy matrix (one embedding per log template).
Everything stays on disk next to the app; nothing is sent anywhere."""
from __future__ import annotations

import sqlite3
from pathlib import Path

import numpy as np

SCHEMA = """
CREATE TABLE IF NOT EXISTS templates(id INTEGER PRIMARY KEY, template TEXT UNIQUE, kind TEXT);
CREATE TABLE IF NOT EXISTS logs(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, node TEXT, level TEXT, tid INTEGER, msg TEXT);
CREATE TABLE IF NOT EXISTS metrics(log_id INTEGER, ts TEXT, node TEXT, name TEXT, value REAL);
CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT);
CREATE INDEX IF NOT EXISTS ix_logs_ts ON logs(ts);
CREATE INDEX IF NOT EXISTS ix_logs_tid ON logs(tid, ts);
CREATE INDEX IF NOT EXISTS ix_met ON metrics(name, node, ts);
"""
OPS = {">": ">", "<": "<", ">=": ">=", "<=": "<="}


class LogStore:
    def __init__(self, data_dir="data"):
        self.dir = Path(data_dir)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.dir / "recall.db")
        self.db.executescript(SCHEMA)
        self.vec_path = self.dir / "template_vecs.npy"
        self._load()

    # ---- setup / meta -------------------------------------------------
    def _load(self):
        rows = self.db.execute("SELECT id, template, kind FROM templates ORDER BY id").fetchall()
        self.tmpl = [r[1] for r in rows]
        self.tkind = [r[2] for r in rows]
        self.tid = {t: i for i, t in enumerate(self.tmpl)}
        self.vecs = np.zeros((0, 0), np.float32)
        if rows and self.vec_path.exists():
            self.vecs = np.load(self.vec_path)
        if len(self.vecs) != len(self.tmpl):
            raise RuntimeError("template vectors out of sync with database - re-run ingest with --reset")

    def get_meta(self, k):
        r = self.db.execute("SELECT v FROM meta WHERE k=?", (k,)).fetchone()
        return r[0] if r else None

    def set_meta(self, k, v):
        self.db.execute("INSERT OR REPLACE INTO meta VALUES(?,?)", (k, v))
        self.db.commit()

    def reset(self):
        for t in ("templates", "logs", "metrics", "meta"):
            self.db.execute(f"DELETE FROM {t}")
        self.db.commit()
        if self.vec_path.exists():
            self.vec_path.unlink()
        self._load()

    # ---- writes -------------------------------------------------------
    def add_templates(self, items, vecs):
        base = len(self.tmpl)
        for i, (t, k) in enumerate(items):
            self.db.execute("INSERT INTO templates(id, template, kind) VALUES(?,?,?)", (base + i, t, k))
            self.tmpl.append(t)
            self.tkind.append(k)
            self.tid[t] = base + i
        self.vecs = vecs if self.vecs.size == 0 else np.vstack([self.vecs, vecs])
        np.save(self.vec_path, self.vecs)
        self.db.commit()

    def set_vectors(self, vecs):
        self.vecs = vecs
        np.save(self.vec_path, vecs)

    def add_logs(self, recs):
        cur = self.db.cursor()
        for r in recs:
            cur.execute("INSERT INTO logs(ts,node,level,tid,msg) VALUES(?,?,?,?,?)",
                        (r["ts"], r["node"], r["level"], self.tid[r["template"]], r["msg"]))
            lid = cur.lastrowid
            for k, v in r["metrics"].items():
                cur.execute("INSERT INTO metrics VALUES(?,?,?,?,?)", (lid, r["ts"], r["node"], k, v))
        self.db.commit()

    # ---- helpers ------------------------------------------------------
    @staticmethod
    def _flt(col, node, t_from, t_to):
        c, p = [], []
        if node:
            c.append(f"{col}node=?"); p.append(node)
        if t_from:
            c.append(f"{col}ts>=?"); p.append(t_from)
        if t_to:
            c.append(f"{col}ts<?"); p.append(t_to)
        return c, p

    def _one(self, sql, p=()):
        r = self.db.execute(sql, p).fetchone()
        return r[0] if r else None

    def nodes(self):
        return [r[0] for r in self.db.execute("SELECT DISTINCT node FROM logs ORDER BY node")]

    def metric_names(self):
        return [r[0] for r in self.db.execute("SELECT DISTINCT name FROM metrics ORDER BY name")]

    def latest_ts(self):
        return self._one("SELECT MAX(ts) FROM logs")

    def first_ts(self):
        return self._one("SELECT MIN(ts) FROM logs")

    def n_logs(self):
        return self._one("SELECT COUNT(*) FROM logs") or 0

    def event_tids(self):
        return [i for i, k in enumerate(self.tkind) if k == "event"]

    # ---- metric (numeric) queries ------------------------------------
    def _mwhere(self, name, op, value, node, t_from, t_to):
        c, p = ["m.name=?"], [name]
        fc, fp = self._flt("m.", node, t_from, t_to)
        c += fc; p += fp
        if op:
            c.append(f"m.value {OPS[op]} ?"); p.append(value)
        return " AND ".join(c), p

    def metric_rows(self, name, op=None, value=None, node=None, t_from=None, t_to=None, order="DESC", limit=10):
        w, p = self._mwhere(name, op, value, node, t_from, t_to)
        o = "DESC" if order == "DESC" else "ASC"
        q = (f"SELECT m.log_id, m.ts, m.node, m.value, l.level, l.msg FROM metrics m JOIN logs l ON l.id=m.log_id "
             f"WHERE {w} ORDER BY m.ts {o}, m.log_id LIMIT ?")
        return [dict(id=r[0], ts=r[1], node=r[2], value=r[3], level=r[4], msg=r[5])
                for r in self.db.execute(q, p + [limit])]

    def metric_count(self, name, op=None, value=None, node=None, t_from=None, t_to=None):
        w, p = self._mwhere(name, op, value, node, t_from, t_to)
        return self._one(f"SELECT COUNT(*) FROM metrics m WHERE {w}", p) or 0

    def metric_count_by_node(self, name, op=None, value=None, node=None, t_from=None, t_to=None):
        w, p = self._mwhere(name, op, value, node, t_from, t_to)
        return self.db.execute(f"SELECT m.node, COUNT(*) FROM metrics m WHERE {w} GROUP BY m.node ORDER BY m.node", p).fetchall()

    def metric_extreme(self, name, which, node=None, t_from=None, t_to=None):
        w, p = self._mwhere(name, None, None, node, t_from, t_to)
        o = "DESC" if which == "max" else "ASC"
        q = (f"SELECT m.log_id, m.ts, m.node, m.value, l.level, l.msg FROM metrics m JOIN logs l ON l.id=m.log_id "
             f"WHERE {w} ORDER BY m.value {o} LIMIT 1")
        r = self.db.execute(q, p).fetchone()
        return dict(id=r[0], ts=r[1], node=r[2], value=r[3], level=r[4], msg=r[5]) if r else None

    def metric_avg(self, name, node=None, t_from=None, t_to=None):
        w, p = self._mwhere(name, None, None, node, t_from, t_to)
        r = self.db.execute(f"SELECT AVG(m.value), COUNT(*) FROM metrics m WHERE {w}", p).fetchone()
        return r[0], r[1]

    def metric_values(self, name, node=None):
        w, p = self._mwhere(name, None, None, node, None, None)
        return np.array([r[0] for r in self.db.execute(f"SELECT m.value FROM metrics m WHERE {w}", p)], float)

    # ---- event (text) queries ----------------------------------------
    def semantic_templates(self, qvec, k=8):
        if not len(self.vecs):
            return []
        sims = self.vecs @ qvec
        out = []
        for i in np.argsort(-sims):
            if self.tkind[int(i)] == "event":
                out.append((int(i), self.tmpl[int(i)], float(sims[i])))
                if len(out) >= k:
                    break
        return out

    def _lwhere(self, tids, node, t_from, t_to, level):
        c, p = self._flt("l.", node, t_from, t_to)
        if tids is not None:
            if not tids:
                return "0", []
            c.append(f"l.tid IN ({','.join('?' * len(tids))})"); p += list(tids)
        if level:
            c.append("l.level=?"); p.append(level)
        return (" AND ".join(c) or "1"), p

    def logs(self, tids=None, node=None, t_from=None, t_to=None, level=None, order="DESC", limit=10):
        w, p = self._lwhere(tids, node, t_from, t_to, level)
        o = "DESC" if order == "DESC" else "ASC"
        q = f"SELECT l.id, l.ts, l.node, l.level, l.msg FROM logs l WHERE {w} ORDER BY l.ts {o}, l.id LIMIT ?"
        return [dict(id=r[0], ts=r[1], node=r[2], level=r[3], msg=r[4]) for r in self.db.execute(q, p + [limit])]

    def count_logs(self, tids=None, node=None, t_from=None, t_to=None, level=None):
        w, p = self._lwhere(tids, node, t_from, t_to, level)
        return self._one(f"SELECT COUNT(*) FROM logs l WHERE {w}", p) or 0

    def count_logs_by_node(self, tids=None, node=None, t_from=None, t_to=None, level=None):
        w, p = self._lwhere(tids, node, t_from, t_to, level)
        return self.db.execute(f"SELECT l.node, COUNT(*) FROM logs l WHERE {w} GROUP BY l.node ORDER BY l.node", p).fetchall()

    def series(self, name, node, limit=5000):
        q = "SELECT ts, value FROM metrics WHERE name=? AND node=? ORDER BY ts DESC LIMIT ?"
        return list(reversed(self.db.execute(q, (name, node, limit)).fetchall()))
