"""Parse raw log lines into structured records (timestamp, node, level, template, numeric fields)."""
from __future__ import annotations

import re

LINE = re.compile(
    r"^(?P<ts>\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d)Z?\s+(?P<node>\S+)\s+"
    r"(?P<level>DEBUG|INFO|WARN|WARNING|ERROR|CRIT|CRITICAL)\s+(?P<msg>.*)$"
)
# name=number, where the number ends at whitespace/comma/semicolon (so "version=1.4.2" is not numeric)
KV = re.compile(r"\b([A-Za-z_]\w*)=(-?\d+(?:\.\d+)?)(?=[\s,;]|$)")
LEVELS = {"WARNING": "WARN", "CRITICAL": "CRIT"}


def make_template(msg: str) -> str:
    """Mask variable parts so identical event types share one template.
    For messy real-world logs swap this for Drain3 (same input/output shape)."""
    t = re.sub(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", "<IP>", msg)
    t = re.sub(r"=\S+", "=<*>", t)
    t = re.sub(r"\b\d+(?:\.\d+)*\b", "<*>", t)
    return t


def parse_line(line: str):
    m = LINE.match(line.strip())
    if not m:
        return None
    d = m.groupdict()
    d["level"] = LEVELS.get(d["level"], d["level"])
    d["kind"] = "metric" if d["msg"].startswith("metric ") else "event"
    d["template"] = make_template(d["msg"])
    d["metrics"] = {k: float(v) for k, v in KV.findall(d["msg"])}
    return d
