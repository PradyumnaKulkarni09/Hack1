"""Embedding backends.

HashEmbedder : numpy only, works anywhere, good enough for the demo / CPU development.
OnnxEmbedder : MiniLM/BGE exported to ONNX (see export_onnx.py). Runs on CPU, or on the Qualcomm
               NPU when the QNN execution provider is available (onnxruntime-qnn on Snapdragon).
"""
from __future__ import annotations

import os
import re
import zlib
from pathlib import Path

import numpy as np

STOP = set("""a an the is are was were be been of on in at to for from by with and or that this it its as
when did does do how what which who show me tell any there then than go went gone goes going time times
last first latest recent please give find list happened happen occur occurred""".split())
_TOK = re.compile(r"[a-z0-9]+")


def _stem(w: str) -> str:
    for suf in ("ing", "ed", "es", "s"):
        if len(w) > len(suf) + 2 and w.endswith(suf):
            return w[: -len(suf)]
    return w


class HashEmbedder:
    min_sim = 0.22

    def __init__(self, dim: int = 1024):
        self.dim = dim
        self.name = f"hash-{dim}"
        self.device = "cpu"

    def _feats(self, text: str):
        words = [_stem(w) for w in _TOK.findall(text.lower()) if w not in STOP]
        feats = [(w, 1.0) for w in words]
        for w in words:
            g = f"#{w}#"
            for n in (3, 4):
                feats += [(g[i:i + n], 0.3) for i in range(len(g) - n + 1)]
        feats += [(a + "_" + b, 0.6) for a, b in zip(words, words[1:])]
        return feats

    def encode(self, texts):
        out = np.zeros((len(texts), self.dim), np.float32)
        for r, t in enumerate(texts):
            for f, w in self._feats(t):
                h = zlib.crc32(f.encode())
                out[r, h % self.dim] += w if (h >> 31) & 1 else -w
        n = np.linalg.norm(out, axis=1, keepdims=True)
        n[n == 0] = 1
        return out / n


class OnnxEmbedder:
    min_sim = 0.35

    def __init__(self, model_path, tokenizer_path, provider="auto"):
        import onnxruntime as ort
        from tokenizers import Tokenizer

        provider = os.getenv("RECALL_PROVIDER", provider).lower()
        avail = ort.get_available_providers()
        order, self.device = [], "cpu"
        if provider in ("auto", "qnn") and "QNNExecutionProvider" in avail:
            order.append(("QNNExecutionProvider", {"backend_path": "QnnHtp.dll", "htp_performance_mode": "burst"}))
            self.device = "npu"
        elif provider == "qnn":
            raise RuntimeError("QNNExecutionProvider not available; install onnxruntime-qnn on a Snapdragon device")
        order.append("CPUExecutionProvider")
        self.sess = ort.InferenceSession(str(model_path), providers=order)
        inp = self.sess.get_inputs()
        self.in_names = [i.name for i in inp]
        self.dtype = np.int32 if "int32" in inp[0].type else np.int64
        shape = inp[0].shape
        self.bs = shape[0] if isinstance(shape[0], int) else 32
        self.seq = shape[1] if isinstance(shape[1], int) else 64
        self.tok = Tokenizer.from_file(str(tokenizer_path))
        self.tok.enable_truncation(self.seq)
        self.tok.enable_padding(length=self.seq)
        self.name = f"onnx-{Path(model_path).stem}"
        self.dim = self.sess.get_outputs()[0].shape[-1]

    def encode(self, texts):
        out = []
        texts = list(texts)
        for i in range(0, len(texts), self.bs):
            batch = texts[i:i + self.bs]
            real = len(batch)
            batch = batch + [""] * (self.bs - real)  # static-shape models need a full batch
            enc = self.tok.encode_batch(batch)
            ids = np.array([e.ids for e in enc], self.dtype)
            mask = np.array([e.attention_mask for e in enc], self.dtype)
            feed = dict(zip(self.in_names, [ids, mask]))
            out.append(self.sess.run(None, feed)[0][:real])
        return np.vstack(out).astype(np.float32) if out else np.zeros((0, 0), np.float32)


class OllamaEmbedder:
    """Neural embeddings from a LOCAL Ollama server. Pure standard library, so it works on any Python
    version (no onnxruntime/torch wheels needed).
        ollama pull all-minilm            # all-MiniLM-L6-v2; or: nomic-embed-text
        RECALL_EMBED_MODEL=all-minilm  RECALL_EMBED_URL=http://127.0.0.1:11434/api/embed
    Non-local hosts are refused unless RECALL_ALLOW_REMOTE=1."""
    min_sim = 0.35

    def __init__(self):
        import urllib.parse
        self.url = os.getenv("RECALL_EMBED_URL", "http://127.0.0.1:11434/api/embed")
        self.model = os.getenv("RECALL_EMBED_MODEL", "all-minilm")
        host = urllib.parse.urlparse(self.url).hostname
        if host not in ("127.0.0.1", "localhost", "::1") and os.getenv("RECALL_ALLOW_REMOTE") != "1":
            raise RuntimeError(f"refusing non-local embedding endpoint {host}")
        self.name = f"ollama-{self.model}"
        self.device = "local-server"
        self.dim = self.encode(["ping"]).shape[1]  # also verifies the server and model are reachable

    def encode(self, texts, batch=64):
        import json
        import urllib.request
        texts = list(texts)
        out = []
        for i in range(0, len(texts), batch):
            body = json.dumps({"model": self.model, "input": texts[i:i + batch]}).encode()
            req = urllib.request.Request(self.url, body, {"Content-Type": "application/json"})
            try:
                with urllib.request.urlopen(req, timeout=120) as r:
                    out.extend(json.load(r)["embeddings"])
            except Exception as e:
                raise RuntimeError(f"Ollama embedding call failed ({e}). Is Ollama running and is "
                                   f"'{self.model}' pulled?") from e
        v = np.array(out, np.float32)
        n = np.linalg.norm(v, axis=1, keepdims=True)
        n[n == 0] = 1
        return v / n


def get_embedder(kind="auto", provider="auto", models_dir="models"):
    if kind == "ollama":
        return OllamaEmbedder()
    md = Path(models_dir)
    model, tok = md / "minilm.onnx", md / "tokenizer.json"
    if kind in ("auto", "onnx") and model.exists() and tok.exists():
        try:
            return OnnxEmbedder(model, tok, provider)
        except Exception as e:  # missing onnxruntime/tokenizers, bad provider...
            if kind == "onnx":
                raise
            print(f"[embedder] ONNX unavailable ({e}); falling back to hash embedder")
    elif kind == "onnx":
        raise FileNotFoundError(f"{model} / {tok} not found - run export_onnx.py first")
    return HashEmbedder()
