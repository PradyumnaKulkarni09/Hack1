"""Compile + profile + run the embedding model on a real Qualcomm NPU via Qualcomm AI Hub (cloud devices).

Setup (one-time):
  pip install qai-hub
  qai-hub configure --api_token <YOUR_TOKEN>        # token from your AI Hub account settings
  python export_onnx.py                              # creates models/minilm.onnx

Run:
  python aihub_compile.py --list-devices
  python aihub_compile.py --device "Snapdragon X Elite"

PRIVACY: this uploads the MODEL and a few sample inputs to Qualcomm's cloud. Use only public models and
synthetic text like below. Never send company logs. Get IT/security approval before using AI Hub at work.

NOTE: AI Hub's Python API evolves. This script was written against the documented compile/inference job
flow (submit_compile_job -> submit_profile_job / submit_inference_job). If a call has changed, check
https://workbench.aihub.qualcomm.com/docs for the current signature.
"""
import argparse

import numpy as np
import qai_hub as hub

SEQ = 64


def api():
    return hub.Client() if hasattr(hub, "Client") else hub


def pick_device(client, name):
    try:
        devs = client.get_devices()
    except Exception:
        return hub.Device(name)  # older/newer API: fall back to exact name
    hits = [d for d in devs if name.lower() in d.name.lower()]
    if not hits:
        raise SystemExit(f"No device matching '{name}'. Run --list-devices.")
    print("using device:", hits[0].name)
    return hits[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="models/minilm.onnx")
    ap.add_argument("--device", default="Snapdragon X Elite")
    ap.add_argument("--list-devices", action="store_true")
    ap.add_argument("--runtime", default="onnx", help="onnx | qnn_context_binary | qnn_dlc | tflite")
    a = ap.parse_args()
    client = api()

    if a.list_devices:
        for d in client.get_devices():
            print(d.name, "|", ",".join(d.attributes))
        return
    device = pick_device(client, a.device)

    print("1/3 compiling for the NPU target ...")
    cj = client.submit_compile_job(
        model=a.model, device=device,
        input_specs={"input_ids": ((1, SEQ), "int32"), "attention_mask": ((1, SEQ), "int32")},
        options=f"--target_runtime {a.runtime}",
    )
    cj.wait()
    target = cj.get_target_model()
    print("   compile job:", cj.job_id, "-> view layer placement (NPU vs CPU) in the AI Hub web UI")

    print("2/3 profiling on a real device ...")
    pj = client.submit_profile_job(model=target, device=device)
    pj.wait()
    try:
        prof = pj.download_profile()
        ms = prof["execution_summary"]["estimated_inference_time"] / 1000
        print(f"   estimated inference time: {ms:.2f} ms | peak memory: "
              f"{prof['execution_summary'].get('inference_memory_peak_range', 'n/a')}")
    except Exception as e:
        print("   profile finished; open it in the web UI (", e, ")")
    print("   profile job:", pj.job_id)

    print("3/3 running inference and comparing with the local CPU result ...")
    ids = np.zeros((1, SEQ), np.int32)
    ids[0, :6] = [101, 4957, 2091, 2006, 8278, 102]
    mask = np.zeros((1, SEQ), np.int32)
    mask[0, :6] = 1
    ij = client.submit_inference_job(model=target, device=device, inputs={"input_ids": [ids], "attention_mask": [mask]})
    ij.wait()
    out = ij.download_output_data()
    npu = np.array(list(out.values())[0][0]).reshape(-1)

    import onnxruntime as ort
    sess = ort.InferenceSession(a.model, providers=["CPUExecutionProvider"])
    dt = np.int32 if "int32" in sess.get_inputs()[0].type else np.int64
    cpu = sess.run(None, {"input_ids": ids.astype(dt), "attention_mask": mask.astype(dt)})[0].reshape(-1)
    cos = float(npu @ cpu / (np.linalg.norm(npu) * np.linalg.norm(cpu)))
    print(f"   cosine(NPU, CPU) = {cos:.4f}  (>0.99 means the NPU model is faithful)")
    print("   inference job:", ij.job_id)
    print("\nSave these job IDs / screenshots of the profile page as hackathon evidence.")


if __name__ == "__main__":
    main()
