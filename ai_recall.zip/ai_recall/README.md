# AI Recall: offline natural-language recall over edge logs

Ask "When was the last time the voltage log spiked above threshold?" and get the answer plus the exact log lines.
Everything (parsing, embeddings, storage, answering) runs locally.

## How it works
1. `logparse.py` parses lines into timestamp / node / level / template / numeric fields.
2. `store.py` keeps numeric fields in SQLite and **one embedding per log template** in a numpy file.
3. `nlq.py` turns the question into a structured plan (rules; optional local LLM in `llm.py`).
4. `engine.py` runs numeric questions as SQL and fuzzy event questions as semantic search over templates,
   then answers with citations to the source log lines.

Numbers are never left to the LLM or to embeddings. That is why "above 250" is exact.

## Quick start (CPU, any laptop)
```
pip install numpy streamlit pandas
python main.py gen                     # synthetic logs + ground truth in data/
python main.py ingest data/edge.log --reset
python main.py ask "When was the last time voltage went above 250 on edge-03?" -v
python main.py chat
streamlit run app.py
python eval.py                         # accuracy / recall@5 / latency against ground truth
```

## NPU path (Qualcomm)
```
pip install torch transformers onnx onnxruntime tokenizers
python export_onnx.py                              # models/minilm.onnx (static shape 1x64)
python main.py ingest data/edge.log --reset --embedder onnx

# A) No device: compile/profile on a real Snapdragon in the cloud (synthetic data only!)
pip install qai-hub && qai-hub configure --api_token <TOKEN>
python aihub_compile.py --list-devices
python aihub_compile.py --device "Snapdragon X Elite"

# B) Snapdragon X laptop (Windows on ARM): pip install onnxruntime-qnn, then
python bench.py                                    # hash vs ONNX-CPU vs ONNX-NPU
python main.py ask "..." --embedder onnx --provider qnn
```
`--embedder auto` picks ONNX automatically once `models/minilm.onnx` exists.

## No onnxruntime wheel for your Python (e.g. Python 3.15)? Use Ollama for embeddings
Standard library only, no extra pip packages:
```
ollama pull all-minilm
python main.py ingest data/edge.log --reset --embedder ollama
python main.py ask "..." --embedder ollama
```
Env vars: `RECALL_EMBED_MODEL` (default `all-minilm`), `RECALL_EMBED_URL` (default `http://127.0.0.1:11434/api/embed`).
Only localhost is allowed. The NPU steps (export_onnx.py, AI Hub) still need torch/onnx, so run those on a machine with a supported Python.

## Optional local LLM
Run any OpenAI-compatible server on this machine (llama.cpp server, Ollama, a Genie wrapper), then:
```
set RECALL_LLM_URL=http://127.0.0.1:11434/v1/chat/completions
set RECALL_LLM_MODEL=llama3.2:3b
python main.py ask "..." --llm
```
The LLM plans the query and phrases the answer. If it fails, rules take over. Non-local URLs are refused.

## Company-hosted LLM endpoint (OpenAI-compatible)
```
set RECALL_LLM_URL=https://<your-endpoint>/v1/chat/completions
set RECALL_LLM_MODEL=<model name the endpoint expects>
set RECALL_LLM_API_KEY=<your key>            # sent as "Authorization: Bearer <key>"
set RECALL_LLM_AUTH_HEADER=api-key           # only if your gateway wants a different header name (Azure-style)
set RECALL_ALLOW_REMOTE=1                    # required for any non-localhost URL
python main.py ask "..." --llm -v
```
Questions, node/field names and matching log lines are sent to that endpoint. Use synthetic logs unless
your security team has approved sending real ones. This is no longer "100% offline".

### Self-signed certificate / check the endpoint first
```
set RECALL_LLM_URL=https://192.168.137.124:30013/V1/chat/completions
set RECALL_LLM_MODEL=Qwen3-4B-Instruct-2507
set RECALL_ALLOW_REMOTE=1
set RECALL_INSECURE_TLS=1        (or RECALL_CA_BUNDLE=<cert file>, preferred)
python check_llm.py              # lists models, sends a test message, explains any error
```
`RECALL_INSECURE_TLS=1` skips certificate checks and is refused for non-private IPs.

## Using your own logs
Line format expected: `YYYY-MM-DDTHH:MM:SS <node> <DEBUG|INFO|WARN|ERROR|CRIT> <message>`. Numeric fields are
picked up from `name=number` pairs in the message. Different format? Edit `LINE` in `logparse.py`.
For messy free-text logs replace `make_template` with Drain3.

## Known limits
- Relative times ("last 2 hours") are relative to the newest log, not wall-clock time.
- The rule planner covers common question shapes; the LLM planner handles odd phrasing.
- The eval uses synthetic data with injected incidents, so treat scores as a regression test, not a real-world claim.
