"""Test your LLM endpoint before using --llm.   python check_llm.py

Uses the same env vars as the app:
  RECALL_LLM_URL      full chat URL, e.g. https://192.168.137.124:30013/V1/chat/completions
  RECALL_LLM_MODEL    e.g. Qwen3-4B-Instruct-2507
  RECALL_LLM_API_KEY  only if the endpoint needs one
  RECALL_ALLOW_REMOTE=1  (any non-localhost host)
  RECALL_CA_BUNDLE=<cert file>  or  RECALL_INSECURE_TLS=1 (private IPs only) for self-signed certificates
"""
import json
import os
import ssl
import sys
import urllib.error
import urllib.request

from airecall import llm

url = os.getenv("RECALL_LLM_URL")
if not url:
    sys.exit("Set RECALL_LLM_URL first (see the header of this file).")
model = os.getenv("RECALL_LLM_MODEL", "")
print(f"URL   : {url}\nModel : {model or '(not set)'}")
ctx = llm.ssl_context(url)


def explain(e):
    if isinstance(e, urllib.error.HTTPError):
        return f"HTTP {e.code} {e.reason}. " + {
            401: "The endpoint wants a key: set RECALL_LLM_API_KEY.",
            403: "Access denied: check the key or whether your machine is allowed to call it.",
            404: "Wrong path. Try /v1 instead of /V1 (or the reverse), and make sure the URL ends in /chat/completions.",
        }.get(e.code, "")
    reason = getattr(e, "reason", e)
    if isinstance(reason, ssl.SSLError) or "CERTIFICATE" in str(reason).upper():
        return ("TLS certificate not trusted (likely a self-signed certificate). Ask the owner for the certificate and set "
                "RECALL_CA_BUNDLE=<file>, or, for a private IP only, set RECALL_INSECURE_TLS=1.")
    return f"{type(e).__name__}: {reason}. Check the IP/port, that you are on the right network/VPN, and any proxy."


def call(req):
    with urllib.request.urlopen(req, timeout=30, context=ctx) as r:
        return json.load(r)


hdr = {"Content-Type": "application/json"}
if os.getenv("RECALL_LLM_API_KEY"):
    name = os.getenv("RECALL_LLM_AUTH_HEADER", "Authorization")
    hdr[name] = f"Bearer {os.environ['RECALL_LLM_API_KEY']}" if name.lower() == "authorization" else os.environ["RECALL_LLM_API_KEY"]

base = url.rsplit("/chat/completions", 1)[0]
print("\n1) Listing models ...")
try:
    ids = [m.get("id") for m in call(urllib.request.Request(base + "/models", headers=hdr)).get("data", [])]
    print("   models offered:", ids)
    if model and ids and model not in ids:
        print(f"   WARNING: '{model}' is not in that list. Use one of the names above for RECALL_LLM_MODEL.")
except Exception as e:
    print("   could not list models (may be fine):", explain(e))

print("\n2) Sending a test question ...")
try:
    body = json.dumps({"model": model, "temperature": 0, "max_tokens": 60,
                       "messages": [{"role": "user", "content": 'Reply with exactly this JSON and nothing else: {"ok": true}'}]}).encode()
    out = call(urllib.request.Request(url, body, hdr))["choices"][0]["message"]["content"]
    print("   reply:", out.strip())
    print("\nEndpoint works. Now run:  python main.py ask \"...\" --llm -v")
except Exception as e:
    sys.exit("   FAILED: " + explain(e))
